package sample;
import java.sql.*;
//import package - step 1
public class Main2 {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Sample","root","root");
		//step 2 create statement
		
				Statement st = c.createStatement();
				String q = "select*from student;";
				// step 3 execute query
		ResultSet rs = st.executeQuery(q);
		//step - 4 process result
				
				while(rs.next()) {
					int id = rs.getInt(1);
					String name = rs.getString(2);
					int ade = rs.getInt(3);
					System.out.println( id+" "+name+" "+ade);
				}
				
	}

}

