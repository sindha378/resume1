
package sample;
import java.sql.*;
public class Main4 {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","root");
		
		
		String q = "insert into student( id ,name,ade )values(?,?,?);";
		PreparedStatement ps = c.prepareStatement(q);
		ps.setInt(1,12);
		ps.setString(2,"nandhu");
		ps.setInt(3,34);
		 
		int r = ps.executeUpdate();
		if(r>0) {
			System.out.println("inserted successfully");
		}else {
			System.out.println("not inserted");
		}
		
		
		
		

	}

}
